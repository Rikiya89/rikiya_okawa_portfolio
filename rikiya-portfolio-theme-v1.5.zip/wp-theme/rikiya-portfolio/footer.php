        <!-- Scroll to top -->
        <i class="scroll-up" id="scroll-up">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icons8-upward-arrow.gif" class="socicon up-arrow"alt="scroll-up" />
        </i>
        
        <!-- Footer section -->
        <footer class="footer">
            <p class="copy">&copy; Rikiya Okawa Copyright 2022</p>
        </footer>
        
    </div> <!-- end l-container -->
    
    <!-- Scripts -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/libraries/jquery.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/libraries/scrollmagic.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/libraries/jquery.easing.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/common.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/js/app.js"></script>
    
    <?php wp_footer(); ?>
</body>
</html>