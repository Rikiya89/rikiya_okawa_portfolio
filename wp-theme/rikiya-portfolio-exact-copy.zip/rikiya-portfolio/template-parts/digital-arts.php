<!-- Digital Arts Section - Exact copy from original static site -->
<section class="digital-arts">
    <div class="anchor-digital-arts" id="digital_arts"></div>
    <div class="digital-arts-inner">
        <h2 class="digital-arts-title fz24">
            Digital Arts
        </h2>
        <ul class="digital-arts-list">
            <li class="digital-arts-item">
                <a href="works05.html" class="digital-arts-block" target="_blank">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/animation.jpg" alt="animation.jpg" loading="lazy" class="digital-arts-pic" />
                    <h3 class="digital-arts-title">
                        Animation Works
                    </h3>
                    <p class="digital-arts-details">
                        After Effects、Premiereを使用したアニメーション作品集
                    </p>
                    <p class="digital-arts-text">
                        Check it Out
                    </p>
                </a>
            </li>
            <li class="digital-arts-item">
                <a href="works06.html" class="digital-arts-block" target="_blank">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/openframeworks.jpg" alt="openframeworks.jpg" loading="lazy" class="digital-arts-pic" />
                    <h3 class="digital-arts-title">
                        openFrameworks
                    </h3>
                    <p class="digital-arts-details">
                        openFrameworksを使用したインタラクティブな作品
                    </p>
                    <p class="digital-arts-text">
                        Check it Out
                    </p>
                </a>
            </li>
            <li class="digital-arts-item">
                <a href="works07.html" class="digital-arts-block" target="_blank">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/p5js.jpg" alt="p5js.jpg" loading="lazy" class="digital-arts-pic" />
                    <h3 class="digital-arts-title">
                        p5.js
                    </h3>
                    <p class="digital-arts-details">
                        p5.jsを使用したジェネラティブアート作品
                    </p>
                    <p class="digital-arts-text">
                        Check it Out
                    </p>
                </a>
            </li>
            <li class="digital-arts-item">
                <a href="works08.html" class="digital-arts-block" target="_blank">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/virtual_cosmos.jpg" alt="virtual_cosmos.jpg" loading="lazy" class="digital-arts-pic" />
                    <h3 class="digital-arts-title">
                        Virtual Cosmos
                    </h3>
                    <p class="digital-arts-details">
                        TouchDesigner、Unityを使用した仮想空間作品
                    </p>
                    <p class="digital-arts-text">
                        Check it Out
                    </p>
                </a>
            </li>
        </ul>
    </div>
</section>