<?php
/**
 * Projects Section Template Part - Exact copy from original static site
 */
?>

<!-- Projects Section -->
<section class="projects">
    <div class="anchor-projects" id="projects"></div>
    <div class="project-inner">
        <h2 class="project-title fz24">
            Some of my Recent Projects
        </h2>
        <ul class="card-list">
            <?php
            // Query for project posts
            $projects_query = new WP_Query(array(
                'post_type' => 'project',
                'posts_per_page' => -1,
                'post_status' => 'publish'
            ));

            if ($projects_query->have_posts()) :
                while ($projects_query->have_posts()) : $projects_query->the_post();
                    $project_url = get_post_meta(get_the_ID(), 'project_url', true);
                    $project_technologies = get_post_meta(get_the_ID(), 'project_technologies', true);
                    $project_type = get_post_meta(get_the_ID(), 'project_type', true);
                    ?>
                    <li class="card-item">
                        <a href="<?php echo esc_url($project_url); ?>" class="card-block project-card-fadein" target="_blank">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array('class' => 'project-pic', 'loading' => 'lazy')); ?>
                            <?php endif; ?>
                            <h3 class="project-title">
                                <?php the_title(); ?>
                            </h3>
                            <p class="project-details">
                                <?php the_excerpt(); ?>
                            </p>
                            <p class="project-text">
                                Check it Out
                            </p>
                        </a>
                    </li>
                    <?php
                endwhile;
                wp_reset_postdata();
            else :
                // Default projects if none are added yet
                ?>
                <li class="card-item">
                    <a href="https://rikiya-okawa-369.vercel.app/jp" class="card-block project-card-fadein" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/new-portfolio.jpg" alt="project03.jpg" loading="lazy" class="project-pic" />
                        <h3 class="project-title">
                            ポートフォリオサイト
                        </h3>
                        <p class="project-details">
                            React、TypeScript、Three.js、Next.jsを学ぶために制作したポートフォリオサイトです。テクノロジーとデザインの融合を意識し、没入感のあるインターフェースを追求しました。モダンな技術とクリエイティブな表現力の向上を目指しています。
                        </p>
                        <p class="project-text">
                            Check it Out
                        </p>
                    </a>
                </li>
                <li class="card-item">
                    <a href="works03.html" class="card-block project-card-fadein" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/project03.jpg" alt="project03.jpg" loading="lazy" class="project-pic" />
                        <h3 class="project-title">
                            グッゲンハイム x ggg Webデザイン
                        </h3>
                        <p class="project-details">
                            UI/UXクラスでAdobe XDを使用し、架空の美術展覧会サイトを制作しました。ユーザーフレンドリーなデザインとインタラクティブな要素に重点を置き、約3時間で完成。ウェブデザインスキル向上に大きく貢献したプロジェクトです。
                        </p>
                        <p class="project-text">
                            Check it Out
                        </p>
                    </a>
                </li>
                <?php
            endif;
            ?>
        </ul>
    </div>
</section>