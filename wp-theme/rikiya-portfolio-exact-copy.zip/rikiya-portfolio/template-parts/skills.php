<!-- Skills section - Exact copy from original static site -->
<section class="skills">
    <div class="anchor-skills" id="skills"></div>
    <h2 class="skill-header fz24">
        My Top Skills
    </h2>
    <div class="skills-wrapper">
        <div class="first-set animate__animated animate__pulse iconSection">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icons8-html-5.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icons8-css3.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icons8-javascript.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/typescript.svg" alt="" loading="lazy" class="icon icon-card" />
        </div>
        <div class="second-set animate__animated animate__pulse iconSection">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/react.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/next.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/sass-1.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/cdnlogo.com_c.svg" alt="" loading="lazy" class="icon icon-card" />
        </div>
        <div class="third-set animate__animated animate__pulse iconSection">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/figma.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Adobe_XD_CC_icon.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Adobe_Photoshop_CC_icon.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Adobe_Illustrator_CC_icon.svg" alt="" loading="lazy" class="icon icon-card" />
        </div>
        <div class="fourth-set animate__animated animate__pulse iconSection">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Adobe_After_Effects_CC_icon.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Adobe_Premiere_Pro_CC_icon.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/Blender_logo.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/touchdesigner.svg" alt="" loading="lazy" class="icon icon-card" />
        </div>
        <div class="fifth-set animate__animated animate__pulse iconSection">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/unity.svg" alt="" loading="lazy" class="icon icon-card" />
            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/icons8-git.svg" alt="" loading="lazy" class="icon icon-card" />
        </div>
    </div>
</section>